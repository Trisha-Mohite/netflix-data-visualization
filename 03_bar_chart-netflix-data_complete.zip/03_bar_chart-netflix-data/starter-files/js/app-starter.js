// STARTER FILE: Netflix movies by genre
// Goal: count how many movies Netflix lists in each genre,
// keep the 10 biggest genres, and draw them as a coloured bar chart.
//
// Data: data/NetflixMovies_added.csv, one row per movie, from Netflix's
// "What We Watched" report (January to June 2025), matched to IMDb genres.
//
// When this file first runs you should see an EMPTY gray-bordered box,
// and two arrays in the console: the raw rows and the movies (still text).
// Do CLEAN 1 to CLEAN 4 first, then STEP 1 to STEP 5 build the chart.

async function main() {
  const app = d3.select('#app')

  // ---- PRE-FILLED: load the data --------------------------------------
  // The ../ goes up one folder, from starter-files to 06_netflix-added.
  const raw = await d3.csv('../data/NetflixMovies_added.csv')
  console.log('raw rows', raw)

  // ---- CLEANING THE DATA -----------------------------------------------
  // Real data never arrives ready to chart. You'll fix it in four steps,
  // CLEAN 1 to CLEAN 4. Check the console after each one.
  //
  // .map() runs once per raw row and builds a NEW, tidier object for it:
  // we keep only the columns we need and give them simple names.
  // Right now every value is still TEXT, exactly as it was in the CSV.
  const movies = raw.map((d) => ({
    title: d.Title,
    views: d.Views, //                 CLEAN 1: put + in front of d.Views
    hours_viewed: d['Hours Viewed'], // CLEAN 1: and in front of this one
    runtime_minutes: d.Runtime, //     CLEAN 2: wrap it: toMinutes(d.Runtime)
    release_date: d['Release Date'],
    genres: d.genres, //               CLEAN 3: wrap it: parseGenres(d.genres)
  }))
  console.log('clean movies', movies)

  // ---- CLEAN 4: one row per movie PER GENRE ----------------------------
  // A movie can have up to three genres. To count genres, "Back in Action"
  // (Action, Comedy) has to become two rows: one with genre "Action", one
  // with genre "Comedy". flatMap makes the rows and flattens them into one
  // list. ...d copies every field of the movie into the new row.
  //
  // const genre_rows = movies.flatMap((d) =>
  // d.genres.map((genre) => ({ ...d, genre: ___ }))
  //  )
  // console.log('one row per movie per genre', genre_rows)


  // ---- STEP 1: count the movies in each genre --------------------------
  // Same rollup as last week's Step 7: group by a category, then reduce
  // each group to one number. Here the number is how many rows it holds.
  //
  // const count_by_genre = d3.rollup(genre_rows, (v) => ___ , (d) => ___ )
  // console.log('count by genre', count_by_genre)



  // ---- STEP 2: sort and keep the top 10  (BUILD THIS TOGETHER, LIVE) --
  // A rollup gives back a Map. To sort it we turn it into an array of
  // [genre, count] pairs, biggest count first, and keep the first 10.
  // In every pair, d[0] is the genre and d[1] is the count.
  //
  // const top_genres = Array.from(count_by_genre)
  //    .sort((a, b) => d3.descending(a[1], b[1]))
  //    .slice(0, ___ )
  //  console.log('top genres', top_genres)



  // ---- PRE-FILLED: an empty SVG to draw in ----------------------------
  const svg = d3
    .create('svg')
    .attr('viewBox', [0, 0, 600, 340])
    .style('border', '1px solid gray')

  // ---- STEP 3: three scales  (BUILD THIS TOGETHER, LIVE) ---------------
  // This time the bars run SIDEWAYS, so the genre names have room to sit
  // on the left. That swaps the jobs of the two axes:
  //   y_scale: genre name -> vertical slot     (scaleBand)
  //   x_scale: count      -> bar length        (scaleLinear)
  // The x range starts at 120 to leave a margin for the names.
  //
  // const y_scale = d3
  //   .scaleBand()
  //    .domain(top_genres.map((d) => ___ ))
  //    .range([20, 320])
  //    .padding(0.15)
  
  //  const x_scale = d3
  //    .scaleLinear()
  //    .domain([0, d3.max(top_genres, (d) => ___ )])
  //    .range([120, 540])
  
  //  const color_scale = d3.scaleOrdinal(d3.schemeCategory10)



  // ---- STEP 4: draw one coloured bar per genre -------------------------
  // Every bar starts at x_scale(0), the left edge of the chart.
  //
  //  const g = svg.append('g').selectAll('g').data(top_genres).join('g')
  //
  //  g.append('rect')
  //    .attr('x', x_scale(0))
  //    .attr('y', (d) => y_scale(d[0]) )
  //    .attr('width', (d) => x_scale(d[1]) - x_scale(0))
  //    .attr('height', y_scale.bandwidth())
  //    .attr('fill', (d) => color_scale(d[0]) )



  // ---- STEP 5: label each bar --------------------------------------------
  // The genre name, right-aligned just left of the bar:
  //
  // g.append('text')
  //   .attr('x', 112)
  //   .attr('y', (d) => y_scale(d[0]) + y_scale.bandwidth() / 2)
  //   .attr('text-anchor', 'end')
  //   .attr('dominant-baseline', 'middle')
  //   .style('font-size', '12px')
  //   .text((d) => ___ )
  //
  // The count, just past the end of the bar:
  //
  // g.append('text')
  //   .attr('x', (d) => x_scale(d[1]) + 6)
  //   .attr('y', (d) => y_scale(d[0]) + y_scale.bandwidth() / 2)
  //   .attr('dominant-baseline', 'middle')
  //   .style('font-size', '12px')
  //   .text((d) => ___ )



  // ---- PRE-FILLED: put the SVG on the page ----------------------------
  app.append(() => svg.node())

  // ---- IF YOU FINISH EARLY (and toward Exercise 2) ---------------------
  // 1. Sum the VIEWS in each genre instead of counting movies:
  //    d3.rollup(genre_rows, (v) => d3.sum(v, (d) => d.views), (d) => d.genre)
  //    Is the biggest genre still the same?
  // 2. Make a histogram of runtime_minutes with d3.bin, like last week.
  // 3. Load ../data/NetflixTV_added.csv instead. Its genres look like
  //    "('Drama', 'Crime')"; parseGenres() already handles that format.
}

// ---- CLEANING HELPERS ------------------------------------------------------
// CLEAN 2: turn "1:54" into 114 (minutes).
// .split() cuts text into a list wherever it finds the character you give it.
function toMinutes(runtime) {
  if (!runtime) return 0
  const parts = runtime.split( ___ ) //  "1:54" -> ["1", "54"]
  return +parts[0] * ___ + +parts[1] // hours to minutes, plus minutes
}

// CLEAN 3: turn "Action,Comedy" into ["Action", "Comedy"].
// PRE-FILLED: .replace() strips the ( ) and ' that the TV file uses, and
// .trim() removes spaces around each name.
// IMDb writes \N when a movie has no genre. In JavaScript a backslash must
// be typed twice, so you write it as '\\N'.
function parseGenres(text) {
  if (!text) return []
  return text
    .replace(/[()']/g, '')
    .split( ___ ) //                                  cut at each comma
    .map((genre) => genre.trim())
    .filter((genre) => genre.length > 0 && genre !== ___ ) // drop no-genre
}

main()
